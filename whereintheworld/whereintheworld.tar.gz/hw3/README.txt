Caroline Ramani

All aspects of the work have been correctly implemented.

Discussed Assignment with: Stephanie Cleland, Tyler Lubeck, Ming Chow

Hours Spent: 5
