//Express initialization
var express = require('express');
var validator = require('validator');
var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//Mongo initialization
var mongoUri = process.env.MONGOLAB_URI ||
process.env.MONGOHQ_URL ||
'mongodb://localhost/whereintheworld'; //put heroku mongo lab user url
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function(error, databaseConnection) {
	db = databaseConnection;
});

app.all('/', function(request, response, next) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	next();
}); 

app.post('/sendLocation', function(request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	var login = request.body.login;
	var lat = request.body.lat;
	var lng = request.body.lng;
	var created_at = Date();
	if (login == undefined || lat == undefined || lng == undefined) {
		console.log("MISSING DATA");
	} else {
	var toInsert = {
		"login": login,
		"lat": lat,
		"lng": lng,
		"created_at": created_at
	};	
	db.collection('locations', function(er, collection) {
		collection.insert(toInsert, function(err, locations) {
			collection.find().limit(100).sort({created_at:-1}).toArray(function(err2, cursor) {
			var toReturn = {
				characters: [],
				students: cursor
			};
			if (err) {
				response.sendStatus(500);
			}
			else {
				response.setHeader("Content-Type", "application/json");
				response.send(JSON.stringify(toReturn));
			}
			});
		});
	});
	}
});


app.get('/', function (request, response) {
	response.set('Content-Type', 'text/html');
	var indexPage = '';
	
	db.collection('locations', function(er, collection) {
		collection.find().sort({created_at:-1}).toArray(function(err, items) {
			if (!err) {
				indexPage += "<!DOCTYPE HTML><html><head><title>MY APP</title></head><body><h1>LOCATION CHECK-INS</h1>";
				for (var c = 0; c < items.length; c++) {
					indexPage += "<p>Login: " + items[c].login + " Location: [" + items[c].lat + ", " + items[c].lng + "] Time: " + items[c].created_at + "</p>";
				}
				indexPage += "</body></html>";
				response.send(indexPage);
			} else {
				response.send('<!DOCTYPE HTML><html><head><title>MY APP</title></head><body><h1>ERROR</h1></body></html>');
			}
		});
	});
});

app.get('/locations.json', function (request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	if (request.query.login == undefined) {
		response.send("[]");	
	} else {
	db.collection('locations', function(er, collection) {
		collection.find({login:request.query.login}).sort({created_at:-1}).toArray(function(err2, cursor) {
		if (err2) {
			response.sendStatus(500);
		}
		else {
			response.setHeader("Content-Type", "application/json");
			response.send(JSON.stringify(cursor));
		}
		});
	});
	}
});

var http = require('http');
app.get('/redline.json', function (request, response) {
	var data = '';
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	http.get("http://developer.mbta.com/lib/rthr/red.json", function(apiresponse) {
		apiresponse.on('data', function(chunk) {
			data += chunk;
		});
		apiresponse.on('end', function() {
			response.send(data);
		});
	}).on('error', function(error) {
		response.sendStatus(500);
	});
});

app.listen(process.env.PORT || 3000);
